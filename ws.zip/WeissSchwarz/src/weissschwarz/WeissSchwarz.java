/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weissschwarz;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author ajk142
 */
public class WeissSchwarz {
    public GamePage gameGui;
    Hand player1Hand;
    Deck player1Deck;
    Hand player2Hand;
    Deck player2Deck;
    boolean cardsDealt = false;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        WeissSchwarz game = new WeissSchwarz();
        game.begin();
    }
    
    public void begin(){
        gameGui = new GamePage();
        gameGui.setVisible(true);
        initPlayerAreas();
        gameGui.DealCardsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dealCards();
            }
        });
    }
    
    public void dealCards(){
        if(cardsDealt == false){
            player1Hand = new Hand();
            player2Hand = new Hand();
            for(int i = 0; i < 5; i++){
                player1Hand.addCard(player1Deck.pop());
                player2Hand.addCard(player2Deck.pop());
            }
            cardsDealt = true;
        }
        updateCardImages();
    }
    
    private void initPlayerAreas(){
        player1Deck = new Deck();
        player2Deck = new Deck();
        player1Deck.shuffle();
        player2Deck.shuffle();
        System.out.println("Decks initialized");
    }
    
    private void updateCardImages(){
        //gameGui.Player1Card1.setIcon(null);
        // 1 through 5
        //gameGui.Player2Card1.setIcon(null);
        // 1 through 5
    }
}
